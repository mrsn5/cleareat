package capprezy.ua.controller;

import capprezy.ua.model.AppUser;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RegisterController {

    @PostMapping
    public ResponseEntity<AppUser> registerUser(@RequestBody AppUser appUser) {
        System.out.println(appUser.toString());
//        userService.register(appUser);
        return ResponseEntity.ok().build();
    }
}
