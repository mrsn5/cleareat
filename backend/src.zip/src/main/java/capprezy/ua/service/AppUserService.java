package capprezy.ua.service;

import capprezy.ua.model.AppUser;
import org.springframework.security.core.userdetails.User;

import java.util.Optional;

public interface AppUserService {
    String login(String username, String password);
    void register(AppUser appUser);
    Optional<User> findByToken(String token);
    AppUser findById(Integer id);
    User loadUserByUsername(String username);

}
