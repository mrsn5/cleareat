package capprezy.ua.service;


import capprezy.ua.model.AppUser;
import capprezy.ua.repository.UserRepository;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service("userService")
public class DefaultUserService implements AppUserService {

    @Autowired
    UserRepository userRepository;

    @Override
    public String login(String username, String password) {
        Optional<AppUser> _user = userRepository.login(username,password);
        if(_user.isPresent()){
            String token = UUID.randomUUID().toString();
            AppUser user = _user.get();
            user.setToken(token);
            userRepository.save(user);
            return token;
        }
        return StringUtils.EMPTY;
    }

    @Override
    public void register(AppUser appUser) {
        Optional<AppUser> _user = userRepository.findByMail(appUser.getMail());
        if (_user.isEmpty()) {
            userRepository.save(appUser);
        } else {
            // todo throw error
        }
    }

    @Override
    public Optional<User> findByToken(String token) {
        Optional<AppUser> _appUser = userRepository.findByToken(token);
        if(_appUser.isPresent()){
            AppUser appUser = _appUser.get();
            User user= new User(appUser.getMail(), appUser.getPassword(), true, true, true, true,
                    AuthorityUtils.createAuthorityList("USER"));
            return Optional.of(user);
        }
        return  Optional.empty();
    }

    @Override
    public User loadUserByUsername(String username) {
        Optional<AppUser> _appUser = userRepository.findByMail(username);
        if(_appUser.isPresent()){
            AppUser appUser = _appUser.get();
            User user= new User(appUser.getMail(), appUser.getPassword(), true, true, true, true,
                    AuthorityUtils.createAuthorityList("USER"));
            return user;
        }
        return null;
    }

    public AppUser findById(Integer id) {
        Optional<AppUser> customer= userRepository.findById(id);
        return customer.orElse(null);
    }
}
